# carlink_native ⇄ ClusterHomeDisplay — AltVideo (USB 0x2C) Integration Spec

**Audience:** the Claude that will implement the producer side in `carlink_native`.
**Counterpart:** consumer side is already prepared in `ClusterHomeDisplay/`.
**Goal:** forward CPC200-CCPA AltVideo (USB MsgType **0x2C**) frames from carlink_native to the ClusterHomeDisplay priv-app so it renders the iOS CarPlay navigation video on the instrument cluster. carlink_native stays thin: it does not decode; it strips headers and broadcasts raw H.264 Annex-B NALs over a bound `Service` + AIDL.

---

## 0. What you are NOT doing

- No MediaCodec, no Surface, no decoder lifecycle in carlink_native. The cluster app owns all of that.
- No new UI in carlink_native.
- Do **not** route 0x2C frames into the existing `videoProcessor` — that processor is for main IHU video (MsgType 0x06) and will choke on a competing stream.

## 1. Consumer is already in place (do not touch it)

`com.carlink.cluster.home` is the priv-app at:
```
~/Documents/carlink/carlink_native/documents/reference/android_studio_emulator/ClusterHomeDisplay/
```

It exposes an `INaviVideoSink` (AIDL) and binds to a Service in `zeno.carlink` at this ComponentName:

```
zeno.carlink / zeno.carlink.ipc.NaviVideoSourceService
```

It expects:
- `onStreamConfigured(int width, int height, int fps)` once per session.
- `onFrame(byte[] h264AnnexB, long ptsUs, boolean isKeyFrame)` per access unit.
- `onStreamEnded()` when the stream stops.

AIDL files (do not duplicate by hand — copy them into carlink_native verbatim so the package + method signatures match exactly):

```
ClusterHomeDisplay/app/src/main/aidl/com/carlink/ipc/INaviVideoSink.aidl
ClusterHomeDisplay/app/src/main/aidl/com/carlink/ipc/INaviVideoSource.aidl
```

In carlink_native, put identical files at:
```
app/src/main/aidl/com/carlink/ipc/INaviVideoSink.aidl
app/src/main/aidl/com/carlink/ipc/INaviVideoSource.aidl
```

Enable AIDL in `app/build.gradle.kts` (mirroring the cluster app):
```kotlin
buildFeatures { aidl = true }
```

## 2. Wire MsgType 0x2C through to a new sink-broadcast Service

### 2.1 Current state (verified Feb 2026)

`MessageTypes.kt:237` already defines:
```kotlin
NAVI_VIDEO_DATA(0x2C), // Navigation video (iOS 13+), same structure as VIDEO_DATA
```

`UsbDeviceWrapper.kt:509-511` already routes 0x2C, **but currently feeds it into the same `videoProcessor` as 0x06**. That is the bug — do **not** keep that wiring.

### 2.2 What to change

1. **Split the demux.** In `UsbDeviceWrapper.kt` (around line 509), branch on `header.type`:
   - `VIDEO_DATA (0x06)` → existing main-video `videoProcessor` (unchanged)
   - `NAVI_VIDEO_DATA (0x2C)` → new `naviVideoForwarder` (see §2.3)
2. **Do not parse the H.264 payload in carlink_native.** Treat everything past the 36-byte total header as opaque bytes.

### 2.3 New: `NaviVideoForwarder`

Suggested path: `app/src/main/kotlin/com/carlink/ipc/NaviVideoForwarder.kt`

Responsibilities:
- Maintain a `RemoteCallbackList<INaviVideoSink>` of registered sinks.
- Track session state: `streamActive`, `lastWidth`, `lastHeight`, `lastFps`.
- On first 0x2C frame of a session, parse the 20-byte video header to extract width/height and call `onStreamConfigured` on all sinks. Use the fps that was sent in `naviScreenInfo` (you control it — see §3).
- On every 0x2C frame, slice out the H.264 payload (everything after the 20-byte video header) and call `onFrame(payload, ptsUs, isKeyFrame)`.
- On stream stop (RELEASE_NAVI_SCREEN_FOCUS cmd 509, CarPlay disconnect, or idle watchdog) call `onStreamEnded` and clear session state.

Frame format reminder (from `documents/reference/adapter/RE_Documention/02_Protocol_Reference/video_protocol.md:125`):

```
[ 16B USB header — already stripped by demux before NaviVideoForwarder sees it ]
[ 20B video header                                                            ]
  0x00  4  width          (LE u32)
  0x04  4  height         (LE u32)
  0x08  4  EncoderState   = 1 for nav video (informational, ignore)
  0x0C  4  PTS            (LE u32, milliseconds, 1kHz adapter clock)
  0x10  4  flags          (LE u32, usually 0)
[ N B H.264 Annex-B NAL units (start code 00 00 00 01)                        ]
```

Reference Kotlin sketch (illustrative, not production code):

```kotlin
class NaviVideoForwarder {
    private val sinks = RemoteCallbackList<INaviVideoSink>()
    private val lock = Any()
    private var streamActive = false
    private var lastW = 0; private var lastH = 0; private var lastFps = 30
    private var configuredFps = 30   // set by host from naviScreenInfo

    fun setRequestedFps(fps: Int) { configuredFps = fps }

    fun onUsbFrame(buf: ByteBuffer) {
        // buf is positioned at start of the 20-byte video header.
        val w   = buf.order(ByteOrder.LITTLE_ENDIAN).getInt(buf.position() + 0x00)
        val h   = buf.getInt(buf.position() + 0x04)
        val ptsMs = (buf.getInt(buf.position() + 0x0C).toLong() and 0xFFFFFFFFL)
        val ptsUs = ptsMs * 1000

        val payloadOffset = buf.position() + 20
        val payloadLen = buf.limit() - payloadOffset
        if (payloadLen <= 0) return
        val payload = ByteArray(payloadLen)
        System.arraycopy(buf.array(), buf.arrayOffset() + payloadOffset,
                         payload, 0, payloadLen)

        val isKey = annexBContainsIdr(payload)

        synchronized(lock) {
            if (!streamActive || w != lastW || h != lastH) {
                lastW = w; lastH = h; lastFps = configuredFps
                streamActive = true
                broadcast { it.onStreamConfigured(w, h, configuredFps) }
            }
        }
        broadcast { it.onFrame(payload, ptsUs, isKey) }
    }

    fun onStreamStop() {
        synchronized(lock) {
            if (!streamActive) return
            streamActive = false
            broadcast { it.onStreamEnded() }
        }
    }

    fun isStreamActive(): Boolean = synchronized(lock) { streamActive }

    fun registerSink(sink: INaviVideoSink) {
        sinks.register(sink)
        // Replay last config to a late-binding consumer so it can show overlay immediately.
        synchronized(lock) {
            if (streamActive) {
                try { sink.onStreamConfigured(lastW, lastH, lastFps) } catch (_: RemoteException) {}
            }
        }
    }
    fun unregisterSink(sink: INaviVideoSink) { sinks.unregister(sink) }

    private inline fun broadcast(action: (INaviVideoSink) -> Unit) {
        val n = sinks.beginBroadcast()
        try { for (i in 0 until n) try { action(sinks.getBroadcastItem(i)) } catch (_: RemoteException) {} }
        finally { sinks.finishBroadcast() }
    }

    /** Scan Annex-B for NAL type 5 (IDR). Type 7 (SPS) / 8 (PPS) typically precede an IDR. */
    private fun annexBContainsIdr(buf: ByteArray): Boolean {
        var i = 0
        while (i < buf.size - 4) {
            if (buf[i].toInt() == 0 && buf[i+1].toInt() == 0 && buf[i+2].toInt() == 0
                && buf[i+3].toInt() == 1 && i + 4 < buf.size) {
                val nalType = buf[i + 4].toInt() and 0x1F
                if (nalType == 5) return true
                i += 4
            } else i++
        }
        return false
    }
}
```

### 2.4 New: `NaviVideoSourceService`

Suggested path: `app/src/main/kotlin/com/carlink/ipc/NaviVideoSourceService.kt`

```kotlin
class NaviVideoSourceService : Service() {
    override fun onBind(intent: Intent): IBinder = object : INaviVideoSource.Stub() {
        override fun registerSink(sink: INaviVideoSink) =
            NaviVideoSingleton.forwarder.registerSink(sink)
        override fun unregisterSink(sink: INaviVideoSink) =
            NaviVideoSingleton.forwarder.unregisterSink(sink)
        override fun isStreamActive(): Boolean =
            NaviVideoSingleton.forwarder.isStreamActive()
    }
}

object NaviVideoSingleton {
    val forwarder = NaviVideoForwarder()
}
```

`UsbDeviceWrapper` (or wherever you do the demux split in §2.2) calls `NaviVideoSingleton.forwarder.onUsbFrame(buf)` for 0x2C.

When `CarlinkManager` echoes `RELEASE_NAVI_SCREEN_FOCUS (509)` back to the adapter (`CarlinkManager.kt:2008`), also call `NaviVideoSingleton.forwarder.onStreamStop()`. Same on CarPlay session end / USB disconnect.

### 2.5 Manifest + permission

In `app/src/main/AndroidManifest.xml` add:

```xml
<permission android:name="com.carlink.permission.NAVI_VIDEO_STREAM"
            android:protectionLevel="signature|privileged" />
<uses-permission android:name="com.carlink.permission.NAVI_VIDEO_STREAM" />

<application ...>
    <service
        android:name=".ipc.NaviVideoSourceService"
        android:exported="true"
        android:permission="com.carlink.permission.NAVI_VIDEO_STREAM" />
</application>
```

**Signing.** `signature|privileged` means caller and provider must share a signing certificate. The cluster app is a priv-app at `/system/priv-app/ClusterHomeDisplay/`. Sign both APKs with the same dev key. The cluster app's `uses-permission` is already declared.

---

## 3. Adapter init — send `naviScreenInfo` in BoxSettings

This is the **primary activation mechanism** (`video_protocol.md:165-167`). The adapter parses `naviScreenInfo` at firmware address `0x16e5c` and branches to `HU_SCREEN_INFO`, **bypassing** the `AdvancedFeatures` config check.

### 3.1 Where

`MessageSerializer.kt` in `serializeBoxSettings()` (around line 404). Insert before the closing `}`:

```kotlin
put("naviScreenInfo", JSONObject().apply {
    put("width",  1920)
    put("height", 620)
    put("fps",    30)
})
```

The cluster display VirtualDisplay is `1920×620` on the emulator (confirmed via `dumpsys display` — see `ClusterHomeDisplay` README context). On the real Silverado, see notes in §6.

### 3.2 What it triggers

Per `documents/reference/adapter/RE_Documention/02_Protocol_Reference/video_protocol.md:697`:

```
1. iPhone connects → CarPlay session up
2. Host BoxSettings includes naviScreenInfo
3. Adapter emits HU_NEEDNAVI_STREAM D-Bus signal
4. Navigation video (Type 0x2C) streaming begins
```

### 3.3 Optional but recommended handshake

`CarlinkManager.kt:2008-2014` already echoes `REQUEST_NAVI_SCREEN_FOCUS (508)` and `RELEASE_NAVI_SCREEN_FOCUS (509)` back to the adapter. Leave that as-is. Tie 509 to `NaviVideoSingleton.forwarder.onStreamStop()` so the consumer hides its overlay deterministically.

### 3.4 What the adapter requires

| Requirement | Status |
|---|---|
| iOS 13+ on the iPhone | required by adapter firmware |
| `naviScreenInfo` in BoxSettings | **required** — primary activation |
| `AdvancedFeatures=1` in config | **NOT required** when `naviScreenInfo` is present (disproven Feb 2026) |
| Cmd 508 echo back | inconclusive — leave it on as precaution |
| CarPlay session active | required — no AA equivalent |

### 3.5 Wireless vs wired

The user has confirmed this adapter delivers AltVideo over USB MsgType **0x2C** for both wireless and wired CarPlay sessions (the adapter terminates the AirPlay TCP stream and re-frames it as USB 0x2C for the host). Treat both transports the same on the host side — your demux only sees USB 0x2C.

(The reference doc at `video_protocol.md:171-178` discusses a separate WiFi TCP type 111 layer, but that's between iPhone and adapter, not adapter and host. Ignore that distinction.)

---

## 4. Frame structure cheat sheet

```
USB packet (already arrives at NaviVideoForwarder with 16-byte USB header stripped):

  +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
  | 0x10 width (LE)   | 0x14 height (LE)  | 0x18 EncState (=1)| 0x1C PTS (ms,LE)  |  20 B video header
  +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
  | 0x20 flags (=0)   |
  +---+---+---+---+---+
  | 00 00 00 01 67 ...   SPS (NAL type 7) — only at session start / after IDR  |
  | 00 00 00 01 68 ...   PPS (NAL type 8)                                       |
  | 00 00 00 01 65 ...   IDR slice (NAL type 5) → isKeyFrame = true             |   N B Annex-B H.264
  | 00 00 00 01 41 ...   non-IDR slice (NAL type 1) → isKeyFrame = false        |
  +-------------------------------------------------------------------------------+
```

PTS conversion: `ptsUs = (header.PTS_ms as u32) * 1000L`. The PTS comes from a 1 kHz adapter clock; cluster MediaCodec only needs monotonic timestamps for ordering, so absolute alignment with anything else doesn't matter.

Observed in a 429-packet capture (Jan 2026): typical 0x2C session = ~1% I-frames + ~99% P-frames. The cluster decoder drops everything until the first `isKeyFrame=true`; do not pre-buffer P-frames on the producer side.

---

## 5. Lifecycle + edge cases

| Event | Producer action |
|---|---|
| First 0x2C frame arrives | `forwarder.onUsbFrame(buf)` — first call broadcasts `onStreamConfigured` |
| Subsequent 0x2C frames | `forwarder.onUsbFrame(buf)` — broadcasts `onFrame` |
| Adapter sends cmd 509 | echo it back (existing code) AND call `forwarder.onStreamStop()` |
| CarPlay session ends | call `forwarder.onStreamStop()` |
| USB disconnect | call `forwarder.onStreamStop()` |
| Resolution change mid-session | `onUsbFrame` detects `w!=lastW || h!=lastH` → broadcasts a new `onStreamConfigured` |
| Consumer process dies | `RemoteCallbackList` auto-cleans on linkToDeath — nothing to do |
| Producer process dies | consumer's linkToDeath fires → consumer hides overlay |

Idle watchdog inside the forwarder is optional. The cluster app already has a 3 s first-frame timeout that hides the overlay if frames stop after `onStreamConfigured`. Adding a producer-side watchdog as well is fine but not required for v1.

---

## 6. Resolution and fps for the real Silverado

> **Full emulator config snapshot:** `reference/emulator_cluster_config.md`
> — actual AVD `config.ini`, `hardware-qemu.ini`, `emu-launch-params.txt`,
> `ClusterOsDouble.apk` decoded dimens, and live `dumpsys display` /
> `dumpsys window displays` output captured from a running `wideAAOS` AVD on
> 2026-05-27/28. Read it if you need to re-verify any number below or sanity-check
> on a fresh emulator instance.

### 6.1 AAOS emulator cluster topology (read this before picking a resolution)

The AAOS automotive emulator has TWO cluster displays in its compositor — pick the right one.

```
EMU_display_1 (HWC 1)                    ←  physical cluster screen
  resolution: 1920 × 720
  owner:      com.android.car.cluster.osdouble  (ClusterOsDoubleActivity)
  draws:      gauge cluster (speedo arc + PRND), bottom strip
              (Fuel/Range, native nav widget), AND embeds the VD below.

  └─ ClusterOsDouble-VD (virtual display, displayId 3)
       resolution: 1920 × 620                  ← what guest activities see
       owner:      com.android.car.cluster.osdouble
       hosts:      com.carlink.cluster.home/.ClusterHomeActivity
                   (and other cluster home candidates)
```

ClusterOsDouble owns the full 1920×720 physical surface and creates a **1920×620** VirtualDisplay for guest activities. The bottom 100 px of the physical surface is reserved for ClusterOsDouble's own UI (PRND, Fuel/Range, native nav widget) and is **unreachable** from any guest activity, including ClusterHomeDisplay. Our app gets the full 1920×620 sandbox with zero insets (`nonDecorInsets=[0,0][0,0]`, `mLogicalSize=1920x620`).

The "100 px" is `ClusterOsDouble.apk`'s `dimen/info_height = 100 dp` (verified by decoding `res/values/dimens.xml` from the on-device APK; at the cluster's 160 dpi density, 100 dp = 100 px). 1920 − 100 = 620. See `reference/emulator_cluster_config.md` §4–§5 for the resource decode and the live `dumpsys` output that confirms `1920×620` at runtime.

Note: the AVD's `config.ini` and `hardware-qemu.ini` do **not** define the cluster display — they only configure the IHU panel (`hw.lcd 2400×960`). The cluster panel is created at runtime by ClusterOsDouble. Editing the AVD config will not change the cluster sandbox size; you'd need to patch `ClusterOsDouble.apk`'s `info_height` dimen and re-flash.

This is the only number that matters for `naviScreenInfo`. **Use `1920×620`, not 1920×720.** A larger request would be cropped/scaled by SurfaceFlinger; you'd consume bandwidth on pixels nobody sees.

Verify if you need to: `adb shell dumpsys display | grep -A1 ClusterOsDouble-VD`.

### 6.2 Resolution + fps targets

| Target | Width | Height | fps | Notes |
|---|---|---|---|---|
| AAOS emulator (display 3 sandbox) | 1920 | 620 | 30 | Confirmed VirtualDisplay size via `dumpsys display` / `dumpsys window displays`. Use this for dev. |
| Real 2024 Silverado IC | TBD | TBD | TBD | Cluster is driven by RH850/P1M-E VIP MCU; AAOS-side IC video pipeline is a separate question. Don't block emulator work on it. |

For the emulator, hardcode `1920×620@30`. If/when targeting the truck, the value goes into the same `naviScreenInfo` JSON — that's the only knob.

Bandwidth budget at 1920×620@30 nav-UI content: ~3–6 Mbps → ~12–25 KB per access unit average. Binder transactions at 30/sec with `oneway` AIDL are well within comfort (default transaction buffer 1 MB). Do not switch to a pipe / shared memory — not needed.

### 6.3 Visual verification helpers (for ad-hoc emulator testing)

```bash
# Screencap the cluster's physical 1920×720 surface (gauge strip visible).
# The HWC display ID below is the EMU_display_1 token from SurfaceFlinger and
# is stable per emulator instance; rediscover with `dumpsys SurfaceFlinger --display-id`
# if a fresh emulator yields a different ID.
adb exec-out screencap -p -d 4619827551948147201 > /tmp/cluster.png

# Inspect the VirtualDisplay (what ClusterHomeActivity sees as display 3).
adb shell dumpsys display | grep -A2 'ClusterOsDouble-VD'
adb shell dumpsys window displays | sed -n '/displayId=3/,/displayId=/p' | head -20

# Activity actually foregrounded on display 3.
adb shell dumpsys activity activities | sed -n '/Display #3/,/Display #/p' | head -20
```

---

## 7. Files you will touch / create

**Modify:**

| Path | What |
|---|---|
| `app/build.gradle.kts` | enable `buildFeatures { aidl = true }` |
| `app/src/main/AndroidManifest.xml` | add `<permission>`, `<uses-permission>`, `<service>` for `NaviVideoSourceService` |
| `app/src/main/kotlin/com/carlink/usb/UsbDeviceWrapper.kt` | split demux: 0x06 → existing path; 0x2C → `NaviVideoSingleton.forwarder.onUsbFrame(buf)` (around line 509) |
| `app/src/main/kotlin/com/carlink/CarlinkManager.kt` | on cmd 509 echo (line 2008), also call `NaviVideoSingleton.forwarder.onStreamStop()`; same on CarPlay end / USB disconnect |
| `app/src/main/kotlin/com/carlink/protocol/MessageSerializer.kt` | add `naviScreenInfo {1920,620,30}` JSON in `serializeBoxSettings()` (line 404 area) |

**Create:**

| Path | What |
|---|---|
| `app/src/main/aidl/com/carlink/ipc/INaviVideoSink.aidl` | copy from `ClusterHomeDisplay/app/src/main/aidl/com/carlink/ipc/INaviVideoSink.aidl` |
| `app/src/main/aidl/com/carlink/ipc/INaviVideoSource.aidl` | copy from `ClusterHomeDisplay/app/src/main/aidl/com/carlink/ipc/INaviVideoSource.aidl` |
| `app/src/main/kotlin/com/carlink/ipc/NaviVideoForwarder.kt` | new — see §2.3 |
| `app/src/main/kotlin/com/carlink/ipc/NaviVideoSourceService.kt` | new — see §2.4 |

**Do not touch:**
- `videoProcessor` / main video pipeline.
- `h264Renderer`, `MediaCodec` setup in carlink_native — none of that applies to AltVideo.
- Cluster-home priv-app — consumer is finished.

---

## 8. Acceptance criteria

A working v1 satisfies all of:

1. With CarPlay session active on the emulator + `naviScreenInfo` sent in BoxSettings, logcat shows USB 0x2C frames arriving at `NaviVideoForwarder`. (Add a `Log.i("NaviForward", "0x2C frame: $payloadLen B, key=$isKey, w×h=$w×$h")` rate-limited to once per second during bring-up.)
2. `adb shell dumpsys activity service zeno.carlink/.ipc.NaviVideoSourceService` shows the service running and the cluster app bound.
3. Cluster logcat (tag `CarlinkHome`) emits `AltVideo stream configured: WxH@FPS` followed by `AltVideo first frame on Surface` within ~2 s of CarPlay nav start.
4. Cluster display 3 (`/tmp/cluster.png` via `adb exec-out screencap -p -d 4619827551948147201`) shows the AltVideo content covering the two cards.
5. Ending the CarPlay route hides the overlay within 3 s and the two cards reappear (`AltVideo stream ended` in cluster logcat).
6. Cluster app, without the carlink_native service bound, still shows nav text + media cards (existing degraded mode — confirmed working as of this writing).

## 9. Out of scope (v2 / later)

- Per-frame stats / decoder telemetry surfaced back to producer.
- ParcelFileDescriptor pipe transport (only if Binder-per-frame becomes a measurable bottleneck — it won't at this bitrate).
- Multiple simultaneous consumers (the design already supports it via `RemoteCallbackList`, no work needed).
- Real-truck IC sizing (`naviScreenInfo` for the Silverado specifically).
- Aspect-ratio / letterbox controls in the cluster app — punted until we see what the adapter actually emits.

---

## 10. Quick verification checklist for the implementer

- [ ] AIDL files copied verbatim, package `com.carlink.ipc`, both files compile.
- [ ] `UsbDeviceWrapper` no longer feeds 0x2C into `videoProcessor`.
- [ ] `NaviVideoForwarder.onUsbFrame` extracts w/h/PTS from the 20-byte header at correct offsets.
- [ ] `naviScreenInfo` JSON appears in BoxSettings on the wire (capture with `riddleBoxCfg -d 2 | grep naviScreenInfo` on the adapter, or watch host TX logs).
- [ ] Service `zeno.carlink/.ipc.NaviVideoSourceService` is exported with `signature|privileged` permission.
- [ ] Both APKs signed with the same key (else `bindService` returns false on the cluster side and you see `NaviVideoSource not available (degraded mode)` in cluster logcat).
- [ ] Cluster logcat shows the four acceptance markers in §8.
