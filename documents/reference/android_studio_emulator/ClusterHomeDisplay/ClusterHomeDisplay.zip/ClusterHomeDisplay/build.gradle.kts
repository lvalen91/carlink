plugins {
    id("com.android.application") version "9.0.0" apply false
}
