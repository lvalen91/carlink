#!/bin/bash
#
# Deploy ClusterHomeDisplay (unified nav+media cluster activity) to AAOS emulator.
# Overrides BOTH config_clusterMapActivity AND config_clusterMusicActivity at priority=100
# so VHAL values 1 (MAPS) and 2 (MUSIC) both land on the combined view.
#
# Sibling ClusterNavigationDisplay and ClusterMediaDisplay can remain installed —
# their overlays are at priority=99 and will be overridden by this one.
#
# Usage:
#   ./deploy.sh [SERIAL]            full install: push + reboot
#   ./deploy.sh fast [SERIAL]       fast redeploy: push + pm install -r + restart, no reboot

set -e

MODE="full"
if [ "$1" = "fast" ]; then MODE="fast"; shift; fi

SERIAL="${1:-emulator-5554}"
ANDROID_HOME="${ANDROID_HOME:-$HOME/Library/Android/sdk}"
ADB="$ANDROID_HOME/platform-tools/adb -s $SERIAL"

APK="app/build/outputs/apk/debug/app-debug.apk"
OVERLAY_APK="overlay/CarlinkClusterHomeOverlay.apk"
PERMISSIONS="permissions/privapp-permissions-clusterhome.xml"
PRIVAPP_PATH="/system/priv-app/ClusterHomeDisplay/ClusterHomeDisplay.apk"
PKG="com.carlink.cluster.home"
ACTIVITY="${PKG}/.ClusterHomeActivity"

# Platform-signing: this priv-app must be signed with the AOSP test platform key so it can hold
# the signature-level INTERNAL_SYSTEM_WINDOW permission (required to launch onto the cluster
# display and auto-default on boot, no manual VHAL command). Keys are the PUBLIC test-keys under
# keys/ (see keys/README.md). Only valid on a test-keys image (ro.build.tags=test-keys).
PLATFORM_PK8="${PLATFORM_PK8:-keys/platform.pk8}"
PLATFORM_CERT="${PLATFORM_CERT:-keys/platform.x509.pem}"
APKSIGNER="$(ls -d "$ANDROID_HOME"/build-tools/*/apksigner 2>/dev/null | sort -V | tail -1)"
SIGNED_APK="/tmp/ClusterHomeDisplay-platform.apk"

if [ ! -f "$APK" ]; then
    echo "ERROR: $APK not found. Build with: ./gradlew assembleDebug"
    exit 1
fi

# Re-sign the (debug-signed) build output with the platform key before installing.
if [ ! -x "$APKSIGNER" ] || [ ! -f "$PLATFORM_PK8" ] || [ ! -f "$PLATFORM_CERT" ]; then
    echo "ERROR: apksigner or platform key missing (apksigner='$APKSIGNER', key='$PLATFORM_PK8')"
    exit 1
fi
cp "$APK" "$SIGNED_APK"
"$APKSIGNER" sign --key "$PLATFORM_PK8" --cert "$PLATFORM_CERT" "$SIGNED_APK" >/dev/null
echo "Platform-signed -> $SIGNED_APK"
if [ "$MODE" = "full" ]; then
    for f in "$OVERLAY_APK" "$PERMISSIONS"; do
        if [ ! -f "$f" ]; then
            echo "ERROR: $f not found. Build overlay per README."
            exit 1
        fi
    done
fi

$ADB root 2>/dev/null || true
sleep 2
$ADB remount 2>/dev/null || true

if [ "$MODE" = "fast" ]; then
    echo "=== Fast redeploy to $SERIAL ==="
    echo "[1/3] Pushing APK..."
    $ADB push "$SIGNED_APK" "$PRIVAPP_PATH"
    echo "[2/3] Reinstalling..."
    $ADB shell pm install -r -d "$PRIVAPP_PATH"
    echo "[3/3] Restarting activity..."
    $ADB shell am force-stop "$PKG"
    sleep 1
    $ADB shell am start --display 3 -n "$ACTIVITY" > /dev/null
    sleep 2
    echo ""
    echo "=== Done (fast) ==="
    echo "Tail logs: adb -s $SERIAL logcat -s ClusterHome"
    exit 0
fi

echo "=== Full deploy ClusterHomeDisplay to $SERIAL ==="
echo "[1/5] Installing priv-app..."
$ADB shell mkdir -p /system/priv-app/ClusterHomeDisplay
$ADB push "$SIGNED_APK" "$PRIVAPP_PATH"

echo "[2/5] Installing privapp permissions..."
$ADB push "$PERMISSIONS" /system/etc/permissions/privapp-permissions-clusterhome.xml

echo "[3/5] Installing RRO overlay..."
$ADB shell mkdir -p /product/overlay/CarlinkClusterHomeOverlay
$ADB push "$OVERLAY_APK" /product/overlay/CarlinkClusterHomeOverlay/CarlinkClusterHomeOverlay.apk

echo "[4/5] Rebooting..."
$ADB reboot
echo "Waiting for boot..."
$ADB wait-for-device
sleep 15
for i in $(seq 1 30); do
    BOOT=$($ADB shell getprop sys.boot_completed 2>/dev/null || echo "0")
    if [ "$BOOT" = "1" ]; then break; fi
    sleep 2
done

echo ""
echo "[5/5] Verifying..."
echo "  Overlay status:"
$ADB shell cmd overlay list com.android.car.cluster.home 2>/dev/null | sed 's/^/    /' || echo "    (unable to check)"
echo "  Package installed:"
$ADB shell pm list packages | grep carlink.cluster.home | sed 's/^/    /' || echo "    NOT FOUND"
echo "  Permissions granted:"
$ADB shell dumpsys package "$PKG" | grep -E "CAR_(INSTRUMENT_CLUSTER_CONTROL|MONITOR_CLUSTER_NAVIGATION_STATE)|MEDIA_CONTENT_CONTROL: granted" | sed 's/^/    /' || echo "    NOT FOUND"

echo ""
echo "=== Done ==="
echo ""
echo "Switch cluster to combined home (use either):"
echo "  adb -s $SERIAL shell cmd car_service inject-vhal-event 0x11400F34 1"
echo "  adb -s $SERIAL shell cmd car_service inject-vhal-event 0x11400F34 2"
echo ""
echo "Or launch directly:"
echo "  adb -s $SERIAL shell am start --display 3 -n $ACTIVITY"
echo ""
echo "Tail logs:  adb -s $SERIAL logcat -s ClusterHome"
