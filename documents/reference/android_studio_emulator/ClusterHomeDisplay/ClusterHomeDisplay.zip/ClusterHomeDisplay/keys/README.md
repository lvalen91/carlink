# Platform signing keys (PUBLIC AOSP test-keys)

These are the **public** AOSP `platform` test-keys, fetched from
`android.googlesource.com/platform/build/.../target/product/security/`. They are NOT secret —
every `test-keys` AOSP/emulator image is signed with them.

ClusterHomeDisplay must be **platform-signed** with these so it can hold the signature-level
`INTERNAL_SYSTEM_WINDOW` permission, which is required to launch the activity onto the cluster
display (`ActivityOptions.setLaunchDisplayId`). Without it the app falls back to a no-op
(CarPropertyManager can't set `CLUSTER_SWITCH_UI`) and you must inject the VHAL event manually
after every boot.

Only valid on a `test-keys` image (`adb shell getprop ro.build.tags` → `test-keys`). A
release-keys / production device needs that device's own platform key (not these).
