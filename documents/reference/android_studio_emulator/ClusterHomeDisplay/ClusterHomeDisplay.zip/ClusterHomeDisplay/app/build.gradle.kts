plugins {
    id("com.android.application")
}

android {
    namespace = "com.carlink.cluster.home"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.carlink.cluster.home"
        minSdk = 32
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        aidl = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
