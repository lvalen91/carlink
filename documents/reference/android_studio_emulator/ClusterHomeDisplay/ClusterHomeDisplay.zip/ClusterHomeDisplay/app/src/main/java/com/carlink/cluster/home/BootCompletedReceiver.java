package com.carlink.cluster.home;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

/**
 * Auto-launches ClusterHomeActivity onto the cluster display on boot, replacing the manual
 * `adb shell cmd car_service inject-vhal-event 0x11400F34 1` step.
 *
 * The original approach (CarPropertyManager.setIntProperty CLUSTER_SWITCH_UI=MAPS) does NOT
 * work from an app — CLUSTER_SWITCH_UI isn't in the app-facing carPropertyConfig list
 * (IllegalArgumentException "property ID is not supported"). We instead launch the activity
 * directly onto the cluster display (see {@link ClusterLaunch}), which needs the signature
 * permission INTERNAL_SYSTEM_WINDOW — granted because this APK is platform-signed.
 *
 * The cluster display ("ClusterOsDouble-VD") may not exist immediately at BOOT_COMPLETED, so
 * we retry on the main thread (held alive via goAsync) until it appears or the budget runs out.
 *
 * Auth: privapp-permissions-clusterhome.xml (INTERNAL_SYSTEM_WINDOW, MANAGE_ACTIVITY_TASKS,
 * INTERACT_ACROSS_USERS).
 */
public class BootCompletedReceiver extends BroadcastReceiver {
    private static final String TAG = "CarlinkHome";
    private static final int MAX_ATTEMPTS = 25;            // ~25 x 2s = 50s budget
    private static final long RETRY_INTERVAL_MS = 2000L;

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)) {
            return;
        }
        final PendingResult pending = goAsync();
        final Context appContext = context.getApplicationContext();
        final Handler handler = new Handler(Looper.getMainLooper());
        final int[] attempt = {0};
        handler.post(new Runnable() {
            @Override
            public void run() {
                attempt[0]++;
                int displayId = ClusterLaunch.findClusterDisplayId(appContext);
                if (displayId >= 0 && ClusterLaunch.launchOnCluster(appContext, displayId)) {
                    Log.i(TAG, "BootCompletedReceiver: launched ClusterHomeActivity on cluster "
                            + "display " + displayId + " (attempt " + attempt[0] + ")");
                    pending.finish();
                    return;
                }
                if (attempt[0] >= MAX_ATTEMPTS) {
                    Log.w(TAG, "BootCompletedReceiver: cluster display not ready after "
                            + MAX_ATTEMPTS + " attempts");
                    pending.finish();
                    return;
                }
                handler.postDelayed(this, RETRY_INTERVAL_MS);
            }
        });
    }
}
