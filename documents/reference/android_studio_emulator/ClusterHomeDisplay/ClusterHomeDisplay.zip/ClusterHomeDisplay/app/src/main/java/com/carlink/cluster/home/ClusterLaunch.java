package com.carlink.cluster.home;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.util.Log;
import android.view.Display;

/**
 * Shared helper for placing ClusterHomeActivity onto the cluster display.
 *
 * Why not CarPropertyManager(CLUSTER_SWITCH_UI)? That property is NOT in the app-facing
 * carPropertyConfig list — setIntProperty throws "property ID is not supported" — so an app
 * cannot drive the cluster UI selector. We instead launch the activity directly onto the
 * cluster display via ActivityOptions.setLaunchDisplayId, which needs the signature-level
 * INTERNAL_SYSTEM_WINDOW permission (granted because this APK is platform-signed with the
 * AOSP test key, matching the test-keys emulator image).
 */
final class ClusterLaunch {
    private static final String TAG = "CarlinkHome";
    static final int FALLBACK_CLUSTER_DISPLAY_ID = 3;

    private ClusterLaunch() {
    }

    /**
     * Resolve the cluster display id ("ClusterOsDouble-VD"), or -1 if it isn't up yet.
     * Matched by name so it survives display-id renumbering across boots.
     */
    static int findClusterDisplayId(Context context) {
        try {
            DisplayManager dm = context.getSystemService(DisplayManager.class);
            if (dm == null) {
                return -1;
            }
            for (Display d : dm.getDisplays()) {
                if (d.getDisplayId() == Display.DEFAULT_DISPLAY) {
                    continue;
                }
                String name = d.getName();
                if (name != null && name.toLowerCase().contains("cluster")) {
                    return d.getDisplayId();
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "findClusterDisplayId failed: " + t.getMessage());
        }
        return -1;
    }

    /** Launch ClusterHomeActivity onto the given display. Returns false on failure. */
    static boolean launchOnCluster(Context context, int displayId) {
        try {
            Intent i = new Intent();
            i.setClassName("com.carlink.cluster.home",
                    "com.carlink.cluster.home.ClusterHomeActivity");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP
                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            ActivityOptions opts = ActivityOptions.makeBasic();
            opts.setLaunchDisplayId(displayId);
            context.startActivity(i, opts.toBundle());
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "launchOnCluster(display=" + displayId + ") failed: " + t.getMessage());
            return false;
        }
    }
}
